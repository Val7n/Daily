<?php

namespace Albert3643\commands;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use Albert3643\utils\Utils;
use Albert3643\provider\Dailys;
use muqsit\invmenu\InvMenu;
use muqsit\invmenu\transaction\InvMenuTransaction;
use muqsit\invmenu\transaction\InvMenuTransactionResult;

class EditMenuSubCommand extends DailyCommand
{
    public function __construct();
    {
     parent::__construct("menu", "edit menu daily");
     $this->setPermission("daily.command.edit");
}

